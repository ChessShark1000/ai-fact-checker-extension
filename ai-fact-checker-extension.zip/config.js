// Backend API configuration
// EC2 instance backend URL
const BACKEND_URL = 'https://ai-factchecker.com';
